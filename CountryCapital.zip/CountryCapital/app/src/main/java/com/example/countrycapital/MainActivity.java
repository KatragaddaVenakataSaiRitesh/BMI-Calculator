package com.example.countrycapital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Spinner countrySp;
    TextView capitalTv,areaTV;
    Button showBtn;
    ImageView flag;
    String country[]={"Canada","India","Jordan","France","Italy","Japan","Germany"};
    String capital[]={"ottawa","delhi","amman","paris","rome","Tokyo","berlin"};
    String area[] = {"9.985 million km²","3.287 million km²","89,342 km²","643,801 km²","301,338 km²","377,915 km²","357,386 km²"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        countrySp=findViewById(R.id.spCountry);
        capitalTv=findViewById(R.id.tvCapital);
        showBtn=findViewById(R.id.btnShow);
        flag=findViewById(R.id.imageView);
        areaTV=findViewById(R.id.tvArea);

        showBtn.setOnClickListener(this);
        countrySp.setOnItemSelectedListener(this);

        //create array adapter and fill it from the array which created as spinner items
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,country);
        //set the array adapter as simple spinner
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data to the Spinner
        countrySp.setAdapter(aa);
    }

    @Override
    public void onClick(View view) {
        //get the index of the selected item in the spinner
        int i=countrySp.getSelectedItemPosition();
        capitalTv.setText(capital[i]);
        String imgName=country[i].toLowerCase();
        int imgId= getResources().getIdentifier(imgName,"drawable",getPackageName());
        flag.setImageResource(imgId);
        areaTV.setText(area[i]);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        capitalTv.setText(capital[i]);
        String imgName=country[i].toLowerCase();
        //if names of image files are img0,img1,img2,..
        // String  imgName = "img"+i

        //to assign image file to image view you need the image id not the image name

        // to get the image id using its name
        int imgId= getResources().getIdentifier(imgName,"drawable",getPackageName());
        //assign the image to the image view using the image id
        flag.setImageResource(imgId);
        areaTV.setText(area[i]);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
